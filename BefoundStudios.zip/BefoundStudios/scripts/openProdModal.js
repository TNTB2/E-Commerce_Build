let currentPage = 0;
let bookPages = [];

function openModal(title, image, description, pages) {
    document.getElementById('modalTitle').innerText = title;
    document.getElementById('modalImage').src = image;
    document.getElementById('modalDescription').innerText = description;
    
    // Store book pages
    bookPages = pages;
    currentPage = 0;
    
    // Show the first page
    updatePage();

    // Show the modal
    document.getElementById('productModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('productModal').style.display = 'none';
}

// Update the page content
function updatePage() {
    document.getElementById('bookContent').innerText = bookPages[currentPage];
    document.getElementById('pageSlider').value = currentPage;
    document.getElementById('currentPage').innerText = `Page ${currentPage + 1} of ${bookPages.length}`;
}

// Next Page
function nextPage() {
    if (currentPage < bookPages.length - 1) {
        currentPage++;
        updatePage();
    }
}

// Previous Page
function prevPage() {
    if (currentPage > 0) {
        currentPage--;
        updatePage();
    }
}

// Handle slider change
function changePage(value) {
    currentPage = parseInt(value);
    updatePage();
}

// Close modal when clicking outside
window.onclick = function (event) {
    if (event.target === document.getElementById('productModal')) {
        closeModal();
    }
}
