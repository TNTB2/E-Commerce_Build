const books = {
    "Product 1": [
        "Page 1: Once upon a time, in a faraway land...",
        "Page 2: The journey began with a mysterious map...",
        "Page 3: Our hero faced their first challenge...",
        "Page 4: As the sun set, hope still lingered..."
    ],
    "Product 2": [
        "Page 1: A scientist made a shocking discovery...",
        "Page 2: The experiment took an unexpected turn...",
        "Page 3: The world was never the same again...",
        "Page 4: A new era of knowledge had begun..."
    ]
};

let currentBook = [];
let currentPage = 0;

function openModal(title, image, description) {
    document.getElementById('modalTitle').innerText = title;
    document.getElementById('modalImage').src = image;
    document.getElementById('modalDescription').innerText = description;
    
    currentBook = books[title] || ["No content available."];
    currentPage = 0;
    updatePage();
    
    document.getElementById('pageSlider').max = currentBook.length - 1;
    document.getElementById('productModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('productModal').style.display = 'none';
}

function updatePage() {
    document.getElementById('bookContent').innerText = currentBook[currentPage];
    document.getElementById('currentPage').innerText = `Page ${currentPage + 1}`;
    document.getElementById('pageSlider').value = currentPage;
}

function nextPage() {
    if (currentPage < currentBook.length - 1) {
        currentPage++;
        updatePage();
    }
}

function prevPage() {
    if (currentPage > 0) {
        currentPage--;
        updatePage();
    }
}

function changePage(value) {
    currentPage = parseInt(value);
    updatePage();
}
