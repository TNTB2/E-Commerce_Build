document.addEventListener("DOMContentLoaded", function () {
    const gallery = document.querySelector(".product-slider");
    
    if (!gallery) {
        console.error("Product slider element not found.");
        return;
    }

    // Ensure each product takes up equal space within the slider
    const products = gallery.querySelectorAll(".product");
    products.forEach(product => {
        product.style.flex = "1 0 auto";
    });

    // Initialize the slider (assuming you're using Slick)
    $(gallery).slick({
        autoplay: true,
        autoplaySpeed: 3000,  // Time between slides
        dots: true,           // Show navigation dots
        arrows: true,         // Enable navigation arrows
        infinite: true,       // Infinite scrolling
        speed: 500,           // Transition speed
        slidesToShow: 4,      // Number of products visible at once
        slidesToScroll: 1,    // Scroll one product at a time
        adaptiveHeight: true, // Adjusts height dynamically
        variableWidth: false, // Ensures products fill the available space
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});